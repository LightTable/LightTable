(defproject com.lighttable/css "0.0.1"
  :description "CSS language plugin for Light Table"
  :dependencies [[org.clojure/clojure "1.5.1"]])
