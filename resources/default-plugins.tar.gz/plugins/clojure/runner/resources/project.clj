(defproject local-client "0.0.1"
  :description "A local light table project"
  :dependencies [[org.clojure/clojure "1.5.1"]])
