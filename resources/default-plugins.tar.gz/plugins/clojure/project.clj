(defproject com.lighttable/clojure "0.0.1"
  :description "Clojure plugin for Light Table"
  :dependencies [[org.clojure/clojure "1.5.1"]])
