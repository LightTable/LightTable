(defproject com.lighttable/paredit "0.0.1"
  :description "paredit plugin for Light Table"
  :dependencies [[org.clojure/clojure "1.5.1"]])
