##Paredit for Light Table

A CLJS implementation of Paredit for Light Table.
